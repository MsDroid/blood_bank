<footer>
        <section>
            <div class="footer-drapper">
                <h3 class="copyright-text">copyright@ all right reserved <span class="ws-link">MS-Droid</span></h3>
            </div>
        </section>
    </footer>

    <!-- Receivers modal start -->



    <!-- Modal -->

    <div class="modal fade" id="receiversModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel">For Receivers</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body text-center">

                    <button type="button" data-bs-toggle="modal" data-bs-target="#receiversRegisterModal"
                        class="btn btn-primary register-btn">Register</button>

                    <button type="button" data-bs-toggle="modal" data-bs-target="#receiverLoginModal"
                        class="btn btn-success login-btn">Login</button>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Back</button>



                </div>

            </div>

        </div>

    </div>

    <!-- end Receivers modal -->



    <!-- Hospitals model -->



    <!-- Modal -->

    <div class="modal fade" id="hospitalsModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel">For Hospitals</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body text-center">

                    <button type="button" data-bs-toggle="modal" data-bs-target="#hospitalsRegisterModal"
                        class="btn btn-primary register-btn">Register</button>

                    <button type="button" data-bs-toggle="modal" data-bs-target="#loginModal"
                        class="btn btn-success login-btn">Login</button>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->

                </div>

            </div>

        </div>

    </div>

    <!-- end hospitals model -->



    <!-- Hospitals register model -->



    <!-- Modal -->

    <div class="modal fade" id="hospitalsRegisterModal" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel">Hospitals Register Form</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body">

                    <form action="index.php" method="POST">

                        <div class="mb-3">

                            <label for="exampleInputName" class="form-label">Hospital Name</label>

                            <input type="text" class="form-control" id="exampleInputName" name="hospital_name"
                                aria-describedby="emailHelp">

                            <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputAddress" class="form-label">Address</label>

                            <input type="text" class="form-control" id="exampleInputAddress" name="address"
                                aria-describedby="emailHelp">

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputEmail1" class="form-label">Email address</label>

                            <input type="email" class="form-control" id="exampleInputEmail1" name="email"
                                aria-describedby="emailHelp">

                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputPassword1" class="form-label">Password</label>

                            <input type="password" class="form-control" name="password" id="exampleInputPassword1">

                        </div>

                        <button type="submit" name="hregister" class="btn btn-primary">Register</button>

                    </form>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->

                </div>

            </div>

        </div>

    </div>

    <!-- end hospitals registers model -->



    <!-- receivers register model -->



    <!-- Modal -->

    <div class="modal fade" id="receiversRegisterModal" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel">Receivers Register Form</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body">

                    <form action="index.php" method="POST">

                        <div class="mb-3">

                            <label for="exampleInputName" class="form-label">Name <span class="star">*</span></label>

                            <input type="text" class="form-control" id="exampleInputName" name="name"
                                aria-describedby="emailHelp" require>

                            <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputAddress" class="form-label">Address <span
                                    class="star">*</span></label>

                            <input type="text" class="form-control" id="exampleInputAddress" name="address"
                                aria-describedby="emailHelp" require>

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputAge" class="form-label">Age <span class="star">*</span></label>

                            <input type="text" class="form-control" id="exampleInputAge" name="age"
                                aria-describedby="emailHelp" require>

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputBloodGroup" class="form-label">Blood Group <span
                                    class="star">*</span></label>

                            <input type="text" class="form-control" id="exampleInputBloodGroup" name="blood_group"
                                aria-describedby="emailHelp" require>

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputContact" class="form-label">Contact No. <span
                                    class="star">*</span></label>

                            <input type="text" class="form-control" id="exampleInputContact" name="contact"
                                aria-describedby="emailHelp" require>

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputEmail1" class="form-label">Email address</label>

                            <input type="email" class="form-control" id="exampleInputEmail1" name="email"
                                aria-describedby="emailHelp">

                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputPassword1" class="form-label">Password <span
                                    class="star">*</span></label>

                            <input type="password" class="form-control" name="password" id="exampleInputPassword1"
                                require>

                        </div>

                        <button type="submit" name="rregister" class="btn btn-primary">Register</button>

                    </form>

                </div>

                <div class="modal-footer">

                    <button type="submit" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->

                </div>

            </div>

        </div>

    </div>

    <!-- end receivers registers model -->



    <!-- hospital login model -->

    <!-- Modal -->

    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel">Hospital Login Form</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body">

                    <form action="index.php" method="POST">

                        <div class="mb-3">

                            <label for="exampleInputEmail1" class="form-label">Email address</label>

                            <input type="email" class="form-control" id="exampleInputEmail1" name="email"
                                aria-describedby="emailHelp">

                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputPassword1" class="form-label">Password</label>

                            <input type="password" class="form-control" name="password" id="exampleInputPassword1">

                        </div>

                        <!-- <div class="mb-3 form-check">

                                <input type="checkbox" class="form-check-input" id="exampleCheck1">

                                <label class="form-check-label" for="exampleCheck1">Check me out</label>

                        </div> -->

                        <button type="submit" name="hlogin" class="btn btn-primary">Login</button>

                    </form>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->

                </div>

            </div>

        </div>

    </div>

    <!-- end hlogin model -->

    <!-- receivers login model -->

    <!-- Modal -->

    <div class="modal fade" id="receiverLoginModal" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">

        <div class="modal-dialog">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel">Receiver Login Form</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body">

                    <form action="index.php" method="POST">

                        <div class="mb-3">

                            <label for="exampleInputEmail1" class="form-label">Email address</label>

                            <input type="email" class="form-control" id="exampleInputEmail1" name="email"
                                aria-describedby="emailHelp">

                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>

                        </div>

                        <div class="mb-3">

                            <label for="exampleInputPassword1" class="form-label">Password</label>

                            <input type="password" class="form-control" name="password" id="exampleInputPassword1">

                        </div>

                        <!-- <div class="mb-3 form-check">

                                <input type="checkbox" class="form-check-input" id="exampleCheck1">

                                <label class="form-check-label" for="exampleCheck1">Check me out</label>

                        </div> -->

                        <button type="submit" name="rlogin" class="btn btn-primary">Login</button>

                    </form>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->

                </div>

            </div>

        </div>

    </div>

    <!-- end rlogin model -->


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>