<?php 
session_start();
include "./database.inc.php";
include "./function.inc.php"
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link rel="icon" href="/assets/images/nbtc-ico.png" type="image/x-icon" />
</head>

<body>
    <header>

        <nav class="navbar navbar-expand-lg navbar">

            <div class="container">

                <a class="navbar-brand" href="index.php">

                    <h1 id="logo">Blood Bank</h1>

                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">

                    <span class="navbar-toggler-icon"></span>

                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                        <li class="nav-item">

                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>

                        </li>

                        <!-- for hospital login -->

                        <?php 

                        if(isset($_SESSION['IS_LOGIN'])){

                            if($_SESSION['UTYPE']=='ADM'){ ?>

                                <li class="nav-item dropdown">

                                    <a class="nav-link dropdown-toggle cap-letter" href="#" id="navbarDropdown" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">

                                        <?php echo $_SESSION['ADMIN_USER']; ?>

                                    </a>

                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">

                                        <li><a class="dropdown-item" href="profile.php">Profile</a></li>

                                        <li><a class="dropdown-item" href="add_blood_sample.php">Add Blood Sample</a></li>

                                        <li><a class="dropdown-item" href="view_request.php">View request sample</a></li>

                                        <li>

                                            <hr class="dropdown-divider">

                                        </li>

                                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>

                                    </ul>

                        </li>

                        <?php } 

                             } else{ ?>

                        <li class="nav-item">

                            <a class="nav-link" data-bs-toggle="modal" data-bs-target="#hospitalsModal" href="#"
                                tabindex="-1">

                                Hospitals

                            </a>

                        </li>

                        <?php }?>

                        <!-- end hospital login -->

                        <!-- For Receiver login -->

                        <?php 

                        if(isset($_SESSION['IS_LOGIN'])){

                            if($_SESSION['UTYPE']=='CST'){ ?>

                        <li class="nav-item dropdown">

                            <a class="nav-link dropdown-toggle cap-letter" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">

                                <?php echo $_SESSION['ADMIN_USER']; ?>

                            </a>

                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">

                                <li><a class="dropdown-item" href="profile.php">Profile</a></li>

                                <li><a class="dropdown-item" href="request_sample.php">Request Blood Sample</a></li>

                                <!-- <li><a class="dropdown-item" href="#">View request sample</a></li> -->

                                <li>

                                    <hr class="dropdown-divider">

                                </li>

                                <li><a class="dropdown-item" href="logout.php">Logout</a></li>

                            </ul>

                        </li>

                        <?php }

                        } else{ ?>

                        <li class="nav-item">

                            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#receiversModal"
                                tabindex="-1">Receivers</a>

                        </li>

                        <?php }?>

                        <!-- End receiver login -->

                    </ul>

                    <form class="d-flex">

                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">

                        <button class="btn btn-outline-success srchbtn" type="submit">Search</button>

                    </form>

                </div>

            </div>

        </nav>

    </header>