<?php include "include/header.php";

if(isset($_SESSION['IS_LOGIN'])!='yes'){
    redirect('index.php');
}

if(isset($_SESSION['IS_LOGIN'])=='yes'){
    if(isset($_SESSION['UTYPE'])=='ADM'){
        $sql = "select * from hospitals";
        $res =mysqli_query($con,$sql);
        $row = mysqli_fetch_assoc($res);
        // prx($row);
    }
}

?>


<div class="cointainer">
    <div class="row profile">
        <h3>Profile Page</h3>
        <div class="line">
            <hr/>
        </div>
            <div class="col-md-6">
                <label for="inputEmail4" class="form-label">Hospital name</label>
                <input type="email" class="form-control" id="inputEmail4" value="<?php echo $row['hospital_name'] ?>">
            </div>
            <div class="col-md-6">
                <label for="inputEmail" class="form-label">Email</label>
                <input type="email" class="form-control" id="inputEmail" value="<?php echo $row['email'] ?>">
            </div>
            <div class="col-12">
                <label for="inputAddress" class="form-label">Address</label>
                <input type="text" class="form-control" id="inputAddress" value="<?php echo $row['address'] ?>">
            </div>
            <!-- <div class="col-md-2">
                <label for="inputZip" class="form-label">Zip</label>
                <input type="text" class="form-control" id="inputZip">
            </div>
            <div class="col-12">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="gridCheck">
                    <label class="form-check-label" for="gridCheck">
                        Check me out
                    </label>
                </div>
            </div> -->
            <!-- <div class="col-12">
                <a href="index.php"><button type="button" class="btn btn-primary">Back</button></a>
            </div> -->
        
    </div>
</div>
<?php include "include/footer.php";?>