<?php include "include/header.php"; 

$msg='';
$name='';
$contact='';
$address='';
$qty='';
$type='';
$hid='';


if(isset($_GET['hid']) && $_GET['hid']!=''){
$hid = $_GET['hid'];
// echo $hid;
}

if(isset($_SESSION['UTYPE'])=='CST'){
    $uid = $_SESSION['uid'];
    $data=mysqli_query($con,"select * from users where uid='$uid'");
    $res=mysqli_fetch_assoc($data);
   
    $name=$res['name'];
    $contact=$res['contact'];
    $address=$res['address'];
    $type=$res['blood_group'];
    $qty=$res['qty'];
    
}

if(isset($_POST['request'])){
    $name=get_safe_value($_POST['name']);
    $contact=get_safe_value($_POST['contact']);
    $city=get_safe_value($_POST['city']);
    $type=get_safe_value($_POST['type']);
    $address=get_safe_value($_POST['address']);
    $qty=get_safe_value($_POST['qty']);
    $hid=get_safe_value($_POST['hid']);

    $sql =mysqli_query($con,"insert into sample_request (name,contact,city,type,address,hid,qty) values('$name','$contact','$city','$type','$address','$hid','$qty')");
    // prx($sql);
    // $res=mysqli_query($con,$sql);
    $msg="Request successfully!!";

}

?>


<div class="container">
    <div class="row sample-data">
        <div class="lrmargin">

            <h2>Request Sample</h2>

        </div>

        <div class="error-msg">

            <?php echo $msg; ?>

        </div>

        <div class="line">
            <hr />
        </div>
        <form class="row g-3" action="request_sample.php?hid=<?php echo $hid ?>" method="POST">
            <div class="col-md-6">
                <label for="inputName" class="form-label">Name <span class="star">*</span></label>
                <input type="text" class="form-control" id="inputName" name="name" value="<?php echo $name; ?>" require>
            </div>
            <div class="col-md-6">
                <label for="inputContact" class="form-label">Contact <span class="star">*</span></label>
                <input type="number" class="form-control" id="inputContact" name="contact"
                    value="<?php echo $contact; ?>" require>
            </div>
            <div class="col-md-4">
                <label for="inputCity" class="form-label">City <span class="star">*</span></label>
                <input type="text" class="form-control" id="inputCity" name="city" require>
            </div>
            <div class="col-md-4">
                <label for="inputCity" class="form-label">Blood Group (Type) <span class="star">*</span></label>
                <input type="text" class="form-control" id="inputCity" name="type" value="<?php echo $type; ?>" require>
            </div>
            <div class="col-md-4">
                <label for="inputQty" class="form-label">Qty <span class="star">*</span></label>
                <input type="number" class="form-control" id="inputCity" name="qty" require>
            </div>
            <div class="col-12">
                <label for="inputAddress" class="form-label">Address <span class="star">*</span></label>
                <input type="text" class="form-control" id="inputAddress" name="address" value="<?php echo $address; ?>"
                    require>
            </div>

            <div class="col-12">
                <!-- <label for="inputHid" class="form-label">hospital_name <span class="star">*</span></label> -->
                <input type="hidden" class="form-control" id="inputHid" name="hid" value="<?php echo $hid; ?>">
            </div>
            <div class="col-12">
                <button type="submit" name="request" class="btn btn-primary">Request</button>
            </div>
        </form>
    </div>
</div>


<?php include "include/footer.php"; ?>