<?php include "include/header.php";

$msg="";

// if(isset($_SESSION['IS_LOGIN'])=='yes'){
//     redirect('index.php');
    
// }


if(isset($_POST['add'])){
    $title =get_safe_value($_POST['title']);
    $blood_group =get_safe_value($_POST['blood_group']);
    $details =get_safe_value($_POST['details']);
    $hid=$_SESSION['hid'];

    
    $sql= "insert into blood_sample (hid,title, blood_group, details) values('$hid','$title','$blood_group','$details')";
    $res =mysqli_query($con,$sql);
    $msg = "Successfully added!";
}


?>


<div class="cointainer">

    <div class="row profile">

        <form method="POST" action="add_blood_sample.php">

            <div class="error-msg">

                <?php echo $msg; ?>

            </div>

            <div class="row mb-3">

                <label for="inputEmail3" class="col-sm-2 col-form-label">Title <span class="star">*<span></label>

                <div class="col-sm-10">

                    <input type="text" class="form-control" id="inputEmail3" name="title" require>

                </div>

            </div>

            <div class="row mb-3">

                <label for="inputBlood" class="col-sm-2 col-form-label">Blood Group <span class="star">*<span></label>

                <div class="col-sm-10">

                    <input type="text" class="form-control" id="inputBlood" name="blood_group" require>

                </div>

            </div>

            <div class="row mb-3">

                <label for="inputDetail" class="col-sm-2 col-form-label">Details</label>

                <div class="col-sm-10">

                    <textarea class="form-control" rows=4 id="inputBlood" name="details"></textarea>

                </div>

            </div>

            <button type="submit" name="add" class="btn btn-primary">Add</button>

        </form>

    </div>

</div>

<?php include "include/footer.php";?>