<?php 
include "include/header.php";

$msg="";
$hid="";

//  Receivers login work
if(isset($_POST['rlogin'])){
    $email =get_safe_value($_POST['email']);
    $password =get_safe_value($_POST['password']);

    // echo  $email;
    $sql= "select * from users where email='$email' and password='$password'";
    $res=mysqli_query($con,$sql);
    // prx($res);
    if(mysqli_num_rows($res)>0){
        $row=mysqli_fetch_assoc($res);
        $_SESSION['IS_LOGIN']='yes';
        $_SESSION['ADMIN_USER']=$row['name'];
        $_SESSION['UTYPE']=$row['utype'];
        $_SESSION['uid']=$row['uid'];
        redirect('profile.php');
      }else{
          $msg="Please enter valid login details";
      }
}

//  hospital login work
if(isset($_POST['hlogin'])){
    $email =get_safe_value($_POST['email']);
    $password =get_safe_value($_POST['password']);

    // echo $email;
    $sql= "select * from hospitals where email='$email' and password='$password'";
    $res=mysqli_query($con,$sql);
    // prx($res);
    if(mysqli_num_rows($res)>0){
        $row=mysqli_fetch_assoc($res);
        $_SESSION['IS_LOGIN']='yes';
        $_SESSION['ADMIN_USER']=$row['hospital_name'];
        $_SESSION['UTYPE']=$row['utype'];
        $_SESSION['hid']=$row['hid'];
        redirect('profile.php');
      }else{
          $msg="Please enter valid login details";
      }
}

// for receiver register
if(isset($_POST['rregister'])){
    $name =get_safe_value($_POST['name']);
    $email =get_safe_value($_POST['email']);
    $address =get_safe_value($_POST['address']);
    $age =get_safe_value($_POST['age']);
    $contact =get_safe_value($_POST['contact']);
    $blood_group =get_safe_value($_POST['blood_group']);
    $password =get_safe_value($_POST['password']);

    $sql = mysqli_query($con,"insert into users (name,email,address,age,contact,blood_group,password,utype) VALUES ('$name','$email','$address','$age','$contact','$blood_group','$password','CST')");
    $msg = "Successfully Registered!!";
}

// for receiver register
if(isset($_POST['hregister'])){
    $hname =get_safe_value($_POST['hospital_name']);
    $email =get_safe_value($_POST['email']);
    $address =get_safe_value($_POST['address']);
    $password =get_safe_value($_POST['password']);

    $sql = mysqli_query($con,"insert into hospitals (hospital_name,email,address,password,utype) VALUES ('$hname','$email','$address','$password','ADM')");
    $msg = "Successfully Registered!!";
}


?>
<main>

    <!-- slider start -->

    <section>

        <div class="error-msg">

            <?php echo $msg; ?>

        </div>

        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">

            <div class="carousel-inner">

                <div class="carousel-item active">

                    <img src="./assets/images/BloodBank_Dpage.png" class="d-block w-100" alt="...">

                </div>

                <div class="carousel-item">

                    <img src="./assets/images/BloodBank_Dpage.png" class="d-block w-100" alt="...">

                </div>

                <div class="carousel-item">

                    <img src="./assets/images/BloodBank_Dpage.png" class="d-block w-100" alt="...">

                </div>

            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="prev">

                <span class="carousel-control-prev-icon" aria-hidden="true"></span>

                <span class="visually-hidden">Previous</span>

            </button>

            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="next">

                <span class="carousel-control-next-icon" aria-hidden="true"></span>

                <span class="visually-hidden">Next</span>

            </button>

        </div>

    </section>

    <!-- slider end -->

    <!-- card section -->

    <section>
    <h3 class=available>Available Blood Sample</h3>
        <div class="line">
            <hr/>
        </div>

        <div class="card-wrapper">

            <?php  

            $sql = "select * from blood_sample";

            $res = mysqli_query($con,$sql);

            while($row = mysqli_fetch_assoc($res)){ 
                // prx($row);
                ?>

            <article class="card">

                <figure class="img-wrapper">

                    <img src="./assets/images/blood-bank.png" width="100%" alt="blood bank">

                </figure>

                <figcaption>
                    <?php 
                
                $hid= $row['hid']; 
                
                $hsql = "select * from hospitals where hid='$hid'";
                $hres=mysqli_query($con,$hsql);
                
                if(mysqli_num_rows($hres)>0){
                    $hrow=mysqli_fetch_assoc($hres);
                    
                }
                ?>
                    <h3 class="card-title"><?php echo $hrow['hospital_name']; ?></h3>

                    <p class="card-desc"><?php echo $row['details']; ?></p>

                    <div class="btn-wrapper">

                        <a href="request_sample.php?hid=<?php echo $row['hid']; ?>"> <button
                                class="btn btn-info sample-btn">Request
                                Sample</button></a>

                    </div>

                </figcaption>

            </article>


            <?php } ?>


        </div>



    </section>


</main>

<?php include "include/footer.php"; ?>