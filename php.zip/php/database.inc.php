<?php 
$con = mysqli_connect('localhost','root','','blood_bank');

if($con->connect_error){
    echo $mysqli->connect_error;
}
?>

