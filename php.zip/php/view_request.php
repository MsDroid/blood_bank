<?php include "include/header.php"; ?>


<div class="container">
    <div class="row sample-data">
        <div class="lrmargin">
            <h2>View Request Page</h2>
        </div>
        <div class="line">
            <hr />
        </div>

        <table class="table lrmargin">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Blood Group (Type)</th>
                    <th scope="col">Qty</th>
                    <th scope="col">City</th>
                    <th scope="col">Address</th>
                </tr>
            </thead>

            <tbody>

                <?php 
            $hid=$_SESSION['hid'];
            // echo $hid;
            $sql=mysqli_query($con,"select * from sample_request where hid=$hid");
            $i=1;
            if(mysqli_num_rows($sql)>0){
                
                while($row=mysqli_fetch_assoc($sql)){ ?>
                <tr>
                    <th scope="row"><?php echo $i; ?></th>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['contact']; ?></td>
                    <td><?php echo $row['type']; ?></td>
                    <td><?php echo $row['qty']; ?></td>
                    <td><?php echo $row['city']; ?></td>
                    <td><?php echo $row['address']; ?></td>
                </tr>

                <?php $i++; }
            }
            ?>
                

            </tbody>
        </table>
    </div>
</div>





<?php include "include/footer.php"; ?>